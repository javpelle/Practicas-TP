package tp.pr3.exceptions;

public class PosicionNoVacia extends Exception {
	public PosicionNoVacia() {
			super ("La celda esta ocupada...\n");
	}
}

