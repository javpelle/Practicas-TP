package tp.pr3.exceptions;

public class FormatoNumericoIncorrecto extends Exception {	
	public FormatoNumericoIncorrecto() {
		super ("No se ha introducido un numero entero...\n");
	}
}
