package tp.pr3.exceptions;

public class PosicionVacia extends Exception {
	public PosicionVacia() {
		super ("La celda esta vacia...\n");
	}
}
