package tp.pr3.exceptions;

public class PalabraIncorrecta extends Exception {
	public PalabraIncorrecta() {
		super ("Se ha le�do una palabra del fichero erronea...\n");
	}
}
