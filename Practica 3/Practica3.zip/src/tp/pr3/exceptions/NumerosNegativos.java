package tp.pr3.exceptions;

public class NumerosNegativos extends Exception {
	public NumerosNegativos() {
		super ("Se han introuducido numeros negativos o nulos que no son validos...\n");
	}
}
