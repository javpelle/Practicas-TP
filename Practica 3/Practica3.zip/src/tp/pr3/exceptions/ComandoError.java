package tp.pr3.exceptions;


public class ComandoError extends Exception {
	public ComandoError() {
		super ("El comando introducido no es valido...\n");
		
	}	
}
