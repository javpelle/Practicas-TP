package tp.pr3.exceptions;

public class NumeroNoValido extends Exception{
	public NumeroNoValido() {
		super ("El numero introducido no es valido...\n");
	}
}
