#include "SinglyLinkedList.h"

using namespace std;

bool resuelveCaso() {
	if (!cin) {
		// fin de la entrada
		return false;
	}
	SinglyLinkedList <int> numeritos;
	int numCasos;
	int numero;
	cin >> numCasos;
	for (int i = 0; i < numCasos; i++) {
		cin >> numero;
		numeritos.push_front(numero);
	}
	if (numCasos == 0) {
		cout << endl << endl;
	}
	else {
		numeritos.mostrar();
		cout << endl;
		numeritos.invertir();
		numeritos.mostrar();
		cout << endl;
	}
	return true;
}

int main() {
	while (resuelveCaso());
	return 0;
}