#include "SinglyLinkedList.h"

using namespace std;


int main() {

	int numero;
	do {
		SinglyLinkedList <int> numeritos;
		cin >> numero;
		if (numero != 0) {
			while (numero != 0) {
				numeritos.push_front(numero);
				cin >> numero;
			}
			numero = -1; // Si hemos llegado hasta aqui, el primer numero es 0 y la ejecucion debe seguir
			numeritos.duplicar();
			numeritos.mostrar();
			cout << endl;
		}
	} while (numero != 0);
	

	return 0;
}